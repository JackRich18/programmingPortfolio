import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.io.*;
import java.util.Scanner;
public class Main {

   public static void main(String[] args)throws Exception{
    String birthString = new String();

    //turn current date in millis
    Date cd = new Date();
    long cdm = cd.getTime();
    //System.out.println(cdm);

    //instructions
    System.out.println("please type your birthdate in format MM-DD-YYYY, dashes included");

    //turn typing into date
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    Scanner sc = new Scanner(System.in);
	  birthString = sc.nextLine();
    Date bd = new SimpleDateFormat("dd-MM-yyyy").parse(birthString);

    //turn date into millis
    long bdm = bd.getTime();
    //System.out.println(bdm);

    // subtract cd by bd
    long et = cdm - bdm;
    //System.out.println(et);

    //convert long et to int
    float eT = (float)et;

    //convert millis to seconds
    float set = eT/1000;
    System.out.println("amount of seconds lived:");
    System.out.println(set);

    //convert seconds to minutes
    float met = set/60;
    System.out.println("amount of minutes lived:");
    System.out.println(met);

    //conver minutes to hours
    float het = met/60;
    System.out.println("amount of hours lived:");
    System.out.println(het);

    //convert hours to days
    float det = het/24;
    System.out.println("amount of days lived:");
    System.out.println(det);

    //convert days to months
    float moet = det/30;
    System.out.println("amount of months lived:");
    System.out.println(moet);

    //convert days to years
    float yet = det/365;
    System.out.println("amount of years lived:");
    System.out.println(yet);

    //convert years to decades
    float deet = yet/10;
    System.out.println("amount of decades lived:");
    System.out.println(deet);

    //convert years to centuries
    float cet = yet/100;
    System.out.println("amount of centuries lived:");
    System.out.println(cet);

    //convert years to milleniums
    float miet = yet/1000;
    System.out.println("amount of milleniums lived:");
    System.out.println(miet);
  }
}
