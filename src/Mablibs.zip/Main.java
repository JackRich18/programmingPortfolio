//Malib by Jack Rich
import java.io.*;
import java.util.Scanner;
import java.lang.Cloneable;
class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
     //create array
    String[] words = {"n","j","a1","v1","v2","ad","i1","i2","v3","p","a2", "mn"};
    System.out.println("please type in a name");
    words[0] = sc.nextLine();
    System.out.println("please type in a job title");
    words[1] = sc.nextLine();
    System.out.println("please type in a adjective");
    words[2] = sc.nextLine();
    System.out.println("please type in a verb");
    words[3] = sc.nextLine();
    System.out.println("please type in a verb");
    words[4] = sc.nextLine();
    System.out.println("please type in a adjective");
    words[5] = sc.nextLine();
    System.out.println("please type in an interjection");
    words[6] = sc.nextLine();
    System.out.println("please type in an interjection");
    words[7] = sc.nextLine();
    System.out.println("please type in a verb");
    words[8] = sc.nextLine();
    System.out.println("please type in a prepostition");
    words[9] = sc.nextLine();
    System.out.println("please type in a adjective");
    words[10] = sc.nextLine();
    System.out.println("please type in a mean name");
    words[11] = sc.nextLine();

    //print 
    System.out.println("here is your madlib");
    //System.out.println(words[0] + " was a " + words[1] + ". ");
    //System.out.println(". At their " + words[2] + " job they liked to " + words[3] + "They were late today, on their way to work they " + words[4]);
    //System.out.println(words[5] + ". A woman exclaimed, " + words[6] + " and " + words[7]);
    
    
    
    System.out.println(words[0] + " was a " + words[1] + ". At their " + words[2] + " job they liked to " + words[3] + ". They were late today, on their way to work they " + words[4] + " " + words[5] + ". A woman exclaimed, " + words[6] + " and " + words[7] + ". The woman " + words[8] + " this " + words[9] + " her " + words[10] + " car. She called them a " + words[11] + " as they hurried to work.");
  }
}