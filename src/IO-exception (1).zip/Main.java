import java.io.IOException;
import java.io.File;
import java.io.PrintWriter;
import java.io.*;
import java.util.Scanner;
import java.lang.Cloneable;

class Main {
  public static void main(String[] args) {
    try{
      File file = new File("output.txt");
      if(!file.exists()) {
        file.createNewFile();
      }
      Scanner sc = new Scanner(System.in);
      String[] words = {"0","1","2","3","4","5","6","7","8","9","10"};
      PrintWriter pw = new PrintWriter(file);
      System.out.println("Please type your answer then press enter");

      System.out.println("What do you want to do as a career?");
      words[0] = sc.nextLine();
      pw.println("What do you want to do as a career? : " + words[0]);

      System.out.println("How do you find happiness in your life?");
      words[1] = sc.nextLine();
      pw.println("How do you find happiness in your life? : " + words[1]);

      System.out.println("What is the purpose of life?");
      words[2] = sc.nextLine();
      pw.println("What is the purpose of life? : " + words[2]);

      System.out.println("Is happiness external or dependent on outside circumstances?");
      words[3] = sc.nextLine();
      pw.println("Is happiness external or dependent on outside circumstances? : " + words[3]);

      System.out.println("Is there a higher power?");
      words[4] = sc.nextLine();
      pw.println("Is there a higher power? : " + words[4]);

      System.out.println("Are cheetos a chip?");
      words[5] = sc.nextLine();
      pw.println("Are cheetos a chip? : " + words[5]);

      System.out.println("Can someone out pizza the Hut?");
      words[6] = sc.nextLine();
      pw.println("Can someone out pizza the Hut? : " + words[6]);

      System.out.println("What is the meaning of life the universe and everything?");
      words[7] = sc.nextLine();
      pw.println("What is the meaning of life the universe and everything? : " + words[7]);

      System.out.println("What is the right question to the answer 42?");
      words[8] = sc.nextLine();
      pw.println("What is the right question to the answer 42? : " + words[8]);

      System.out.println("Can a computer be conscious?");
      words[9] = sc.nextLine();
      pw.println("Can a computer be conscious? : " + words[9]);

      System.out.println("Can computers ever be human in any meaningful way?");
      words[10] = sc.nextLine();
      pw.println("Can computers ever be human in any meaningful way? : " + words[10]);

      pw.println(" ");
      pw.close();
      System.out.println("Thank you, your answers have been recorded in the output.txt file");

    } catch(IOException ioe) {
      System.out.println("booooo");
      ioe.printStackTrace();
    }
  }
}