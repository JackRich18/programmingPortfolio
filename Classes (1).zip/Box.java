public class Box {
  //member variables
  double l,w,h;

  //constructor
  Box(double l, double w, double h){
    this.l = l;
    this.w = w;
    this.h = h;
  }
  
  //caluclations
  double calcVolume() {
    double volume = l*w*h;
    return volume;
  }
  double calcsA(){
    double sA = 2*(l*w + l*h + h*w);
    return sA;
  } 
}