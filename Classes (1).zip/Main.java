import java.util.Scanner;
import java.lang.Math;
class Main {
  public static void main(String[] args) {
    int x = 0;
    while(x < 1){
      System.out.println("welcome to the ShapeCalculator");
      System.out.println("for box please enter 1, for pyramid enter 2, for sphere enter 3");
      Scanner sc = new Scanner(System.in);   
      int num = sc.nextInt();

      //box
      if(num < 2){
        System.out.println("you chose a box");
        System.out.println("Please enter a length");
        double templ = sc.nextDouble();
        System.out.println("Please enter a width");
        double tempw = sc.nextDouble();
        System.out.println("Please enter a height");
        double temph = sc.nextDouble();
        Box myBox = new Box(templ,tempw,temph);
        System.out.println("volume: " + myBox.calcVolume());
        System.out.println("surface area: " + myBox.calcsA());
      }//Pyramid
      if(num == 2){
        System.out.println("you chose a pyramid");
        System.out.println("Please enter a length");
        double tempx = sc.nextDouble();
        System.out.println("Please enter a width");
        double tempy = sc.nextDouble();
        System.out.println("Please enter a height");
        double tempz = sc.nextDouble();
        Pyramid myPyramid = new Pyramid(tempx,tempy,tempz);
        System.out.println("volume: " + myPyramid.calcVolume());
        System.out.println("surface area: " + myPyramid.calcsA());
      }//Sphere
      if(2 < num){
        System.out.println("you chose a sphere");
        System.out.println("Please enter a radius");
        double tempr = sc.nextDouble();
        Sphere mySphere = new Sphere(tempr);
        System.out.println("volume: " + mySphere.calcVolume());
        System.out.println("surface area: " + mySphere.calcsA());
      }
    }
  }
}
