public class Pyramid {
  //member variables
  double l,w,h;

  //constructor
  Pyramid(double l, double w, double h){
    this.l = l;
    this.w = w;
    this.h = h;
  }
  
  //caluclations
  double calcVolume() {
    double volume = l*w*h/3;
    return volume;
  }
  double calcsA(){
    double sA = l*w + l*(Math.sqrt((w*w/4)+h*h)) + w*(Math.sqrt((l*l/4)+h*h));
    return sA;
  } 
}