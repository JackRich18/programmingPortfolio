public class Sphere {
  //member variables
  double r;

  //constructor
  Sphere(double r){
    this.r = r;
  }
  
  //caluclations
  double calcVolume() {
    double volume = (4/3)*3.14*r*r*r;
    return volume;
  }
  double calcsA(){
    double sA = 4*3.14*r*r;
    return sA;
  } 
}